package com.algorithm;

public class Main {

    public static void main(String[] args) {
        CalculateBills cb = new CalculateBills();
        cb.calculateBills(99);
        cb.calculateBills(100);
        cb.calculateBills(101);
        cb.calculateBills(150);
        cb.calculateBills(151);
        cb.calculateBills(200);
        cb.calculateBills(201);
        cb.calculateBills(300);
    }
}
