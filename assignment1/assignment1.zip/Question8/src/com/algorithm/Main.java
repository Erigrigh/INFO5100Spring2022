package com.algorithm;

public class Main {

    public static void main(String[] args) {
        PromptsGrade p = new PromptsGrade();
        p.promptsGrade("A");
        p.promptsGrade("B");
        p.promptsGrade("C");
        p.promptsGrade("D");
        p.promptsGrade("E");
        p.promptsGrade("F");
        p.promptsGrade(" ");
        p.promptsGrade("");
    }
}
