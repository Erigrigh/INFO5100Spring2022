package com.algorithm;

public class Main {

    public static void main(String[] args) {

        Box box = new Box(2.0, 3.0, 6.0);
        box.calculateBoxVolume();

        Box box1 = new Box(0.0, 0.0, 0.0);
        box1.calculateBoxVolume();


    }
}
